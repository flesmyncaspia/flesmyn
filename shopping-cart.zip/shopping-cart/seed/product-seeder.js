var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('mongodb+srv://pippo:pippo123@cluster1-oxmoe.mongodb.net/shopping?retryWrites=true&w=majority' ,{useNewUrlParser:true , useUnifiedTopology: true});


var products =[
     new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72529434_118487032895918_3096170219207393280_n.jpg?_nc_cat=105&_nc_eui2=AeE1QDp8bVlnndWo0sA7S7PTA0Rs5CfG3sUd_Yd0PMeN6NFLnyfpEFxiq36VW_gd_zZtLt06flKMBT1IhoWRZy4YthjedL8CiEQGPw50KOJ2kw&_nc_oc=AQkVut6t6QGPDnz8KAkwS33hr7R6BBEnfbhff2-13ZJD6rKdOxTv-hC0ohLjQgeBWoY&_nc_ht=scontent-sin6-1.xx&oh=2dadde0d82dc284a053d143ee5552c27&oe=5E1D5869',
         product_name: 'Aqua Botol 1.5L',
         product_description: 'Aqua Botol 1.5L/1500ml/1 dus = 12 botol ',
         product_category: 'Kemasan ',
         product_sub_category: 'Mineral',
         product_code: 'A0011',
         price: 49000
        }),
     new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72396280_118562319555056_3793099379619921920_n.jpg?_nc_cat=102&_nc_eui2=AeFibdRt9he5tbg6m32PPJpjDzMQXMHzgdaNi9Q8qHJ6I6861r4sXUl1TCmxDKfJFf719mtWPz_zWzuoWJ-0jBgtjwfunOBLuYS4M0Aev4JK9g&_nc_oc=AQnpONAjqcccmv5GbvQV5R4ia7_6O1o8hbW5opbsuIO1KK0gNmb8lz-Kg3iPFTaw3tY&_nc_ht=scontent-sin6-1.xx&oh=655a38b6c73e9bb5f893f2d279a923f4&oe=5E5F64E4',
         product_name: 'Aqua Botol 600ml',
         product_description: 'Aqua Botol 600ml / 1 dus = 24 botol',
         product_category: 'Kemasan ',
         product_sub_category: 'Mineral',
         product_code: 'A0009',
         price: 46000
        }),
     new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72849984_118582869553001_4421746832133062656_n.jpg?_nc_cat=101&_nc_eui2=AeFNOYYYUrKyGLBTDu1sEFmZ64fQkuCR4ctw_rcgCOOy7d-RTfEFluyvJV6rNp0FBZ7wVd_BYbHmFvhO8dEqq-oH2H7tkZPOqEzVglR2WJeSLw&_nc_oc=AQlLEKaIX76WINAPkRgnxyqQlqhQNAHYsS7-0brXMsBkJrB5V3KJWkBENdH4ber3bWM&_nc_ht=scontent-sin6-1.xx&oh=23a273a06205997c1839e54b1b42b884&oe=5E229CB6',
         product_name: 'Aqua Botol 330ml',
         product_description: 'Aqua Botol 330ml / 1 dus = 24 botol', 
         product_category: 'Kemasan ',
         product_sub_category: 'Mineral',
         product_code: 'A0013',
         price: 37000
        }),
    new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72601774_118584596219495_2774673663490785280_n.jpg?_nc_cat=102&_nc_eui2=AeFCU0xsQb_5ywp9L6x1RJ-ES_jHZXk17jyf-spJKTFaKPTCCz4qW4JVFC-_VjYvGqLoM-4XRKj0C-Fk6ybXfr7JxcrGQKRLYpDIPXlP7HWmhQ&_nc_oc=AQk0zIPKOQVTlsGoAu5qG07fi166HF31yl4OtvbfY214-RYIDaxQ9-ZN9hbHyO6BH80&_nc_ht=scontent-sin6-1.xx&oh=9e8834209008d4c220021abd797105f1&oe=5E2AF019',
         product_name: 'Aqua Gelas 220ml',
         product_description: 'Aqua Gelas 1 dus = 48 pcs', 
         product_category: 'Kemasan ',
         product_sub_category: 'Mineral',
         product_code: 'A0010',
         price: 31000
        }),
    new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72569710_118586386219316_634448389961940992_n.jpg?_nc_cat=110&_nc_eui2=AeF-r_zQNoq53G3Vwpcuo36O3mO2DYr8gV3eMkBthPb7T3OwWrNfi4WRAbu6Sp49k0jQiPsRdtkrEYZlzLl-fej5nF6LW1yawbU7bXLosHSn_A&_nc_oc=AQlcsFVl7fYVnDqKhYmx62tdGDYiu1OTQn7CLUzeXJ6qjlxpTsEKi7HYtdPlye_KBeM&_nc_ht=scontent-sin6-1.xx&oh=ac600c38beaab4567bcbd3e730b6870f&oe=5E266E31',
         product_name: 'Aqua Galon 19lt',
         product_description: 'Aqua Galon 19lt', 
         product_category: 'Galon ',
         product_sub_category: 'Mineral',
         product_code: 'A0001',
         price: 18000
        }),
    new Product({
         imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72175532_118587566219198_3802945630800707584_n.jpg?_nc_cat=103&_nc_eui2=AeGPw9SCR18Mvn6UxMQINBhl-LNuiVn8Hy_q1Qq3c6Hwuy3aOieDxwh1f-bPBMHEAtZm4qE9tKZiJgdRMUSKPwZIeRd9i8Y7upv3PHW0PRbJNw&_nc_oc=AQmZ-0NYAekRj73UkuXQ20eE-hem_9ud7MLauEDq-aNwmA7nvyS963D0cRFAhQJwYJA&_nc_ht=scontent-sin6-1.xx&oh=5e782278837fc312c27850cde05e49af&oe=5E5FC2E0',
         product_name: 'Vit Galon 19lt',
         product_description: 'Vit Galon 19lt', 
         product_category: 'Galon ',
         product_sub_category: 'Mineral',
         product_code: 'A0008',
         price: 16000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72336715_119214809489807_6704517998587150336_n.jpg?_nc_cat=104&_nc_eui2=AeHTuDvsuHFY2_B3s25JDE3Sj7L4q3STex8CXqAiF9ZI-yxRfRxR9C9P-x8Y05DvsBpM5i-KO48EsNdk1_MMfYnVYjh4PCf_c66SauX7KWttYQ&_nc_oc=AQlXC7tTYvHy3IRKUPUoVuTypRQE4_lPGkFWSdx6_nNZZlbxlWY-O1FjC8jHZCCELsQ&_nc_ht=scontent-sin6-1.xx&oh=f8915e12f6232673dbb78dde464df315&oe=5E3225F0',
        product_name: 'Vit Botol 1500ml',
        product_description: 'Vit Galon 1500ml', 
        product_category: 'Kemasan ',
        product_sub_category: 'Mineral',
        product_code: 'A0100',
        price: 33000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72286259_119220796155875_2989373147267989504_n.jpg?_nc_cat=102&_nc_eui2=AeFjDGji10vlyM5dkrVUWGIRsDlVoGfN28aukIEih1LQMwreM1SXO2qF8amRXzxEz45hFOmYIjTknzaRgF1uhvurCyyLhjxuvYZWlE1lPDQx0g&_nc_oc=AQkFIgnsv4Ha2Xjad1YvUv96e3lMQngsU9nvh76_2OgHapi8gbK2Uj7Ur4mOEWUYz3g&_nc_ht=scontent-sin6-1.xx&oh=3fa3e4a8acbd2a3b022ad0694f701d9d&oe=5E196284',
        product_name: 'Vit 600mL',
        product_description: 'Vit Botol 600ml / 1 dus', 
        product_category: 'Kemasan ',
        product_sub_category: 'Mineral',
        product_code: 'A0054',
        price: 36000
        }),

    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73147493_119228009488487_5279292981843591168_n.jpg?_nc_cat=100&_nc_eui2=AeF7QqncOUWpsWLa3FbewjndWTVkaSz7u-Vxe9v6AoawBAs5FdL5OaTjnQZuhHtJ_GAFgu_37NVOWC_z2aPlPek8KM9nX9KJxDFQdpqEbGxyzA&_nc_oc=AQnp7nTwUQ6m7Z72jl-sL2rSjPrMlhZnSlklbnW_yPkQJSZ8_pwDr9SXC3IMisEQZcU&_nc_ht=scontent-sin6-1.xx&oh=b00d479a98bf327a64a648e8f4cf83a7&oe=5E17B464',
        product_name: 'Vit Gelas 240mL',
        product_description: 'Vit Gelas 240ml / dus', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0012',
        price: 24000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72286259_119220796155875_2989373147267989504_n.jpg?_nc_cat=102&_nc_eui2=AeFjDGji10vlyM5dkrVUWGIRsDlVoGfN28aukIEih1LQMwreM1SXO2qF8amRXzxEz45hFOmYIjTknzaRgF1uhvurCyyLhjxuvYZWlE1lPDQx0g&_nc_oc=AQkFIgnsv4Ha2Xjad1YvUv96e3lMQngsU9nvh76_2OgHapi8gbK2Uj7Ur4mOEWUYz3g&_nc_ht=scontent-sin6-1.xx&oh=3fa3e4a8acbd2a3b022ad0694f701d9d&oe=5E196284',            
        product_name: 'Vit Botol 600ml',
        product_description: 'Vit Botol 600ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0657',
        price: 2000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72529434_118487032895918_3096170219207393280_n.jpg?_nc_cat=105&_nc_eui2=AeE1QDp8bVlnndWo0sA7S7PTA0Rs5CfG3sUd_Yd0PMeN6NFLnyfpEFxiq36VW_gd_zZtLt06flKMBT1IhoWRZy4YthjedL8CiEQGPw50KOJ2kw&_nc_oc=AQkVut6t6QGPDnz8KAkwS33hr7R6BBEnfbhff2-13ZJD6rKdOxTv-hC0ohLjQgeBWoY&_nc_ht=scontent-sin6-1.xx&oh=2dadde0d82dc284a053d143ee5552c27&oe=5E1D5869',
        product_name: 'Aqua Botol 1.5L',
        product_description: 'Aqua Botol 1.5L/1500ml/pcs ',
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0516',
        price: 6000
        }),  
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72849984_118582869553001_4421746832133062656_n.jpg?_nc_cat=101&_nc_eui2=AeFNOYYYUrKyGLBTDu1sEFmZ64fQkuCR4ctw_rcgCOOy7d-RTfEFluyvJV6rNp0FBZ7wVd_BYbHmFvhO8dEqq-oH2H7tkZPOqEzVglR2WJeSLw&_nc_oc=AQlLEKaIX76WINAPkRgnxyqQlqhQNAHYsS7-0brXMsBkJrB5V3KJWkBENdH4ber3bWM&_nc_ht=scontent-sin6-1.xx&oh=23a273a06205997c1839e54b1b42b884&oe=5E229CB6',
        product_name: 'Aqua Botol 330ml',
        product_description: 'Aqua Botol 330ml /pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0572',
        price: 2000
        }),  
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72286508_119239336154021_7323304262023249920_n.jpg?_nc_cat=100&_nc_eui2=AeHM5tOd8EdGVyuFbbG54sJAZAhjLSOLuOOGpVYJSD1XnyPDoOVlsdZSf5R0gtakF4G5Z2xJTywM0f0juJEp1skMOoRgC8pVKssXr902c1qKHQ&_nc_oc=AQl13lnuLgnfUW1rPovyBq_wP3YtwRywASGrdJ_jWN9sGc8mhxzMJzEqyntf8TbsbRo&_nc_ht=scontent-sin6-1.xx&oh=32679df2adfa3522bb48ce58f745f885&oe=5E1BA021',
        product_name: 'Le Mineral Botol 1500ml',
        product_description: 'Le Mineral Botol 1500ml/dus 12 botol', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0131',
        price: 48000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72286508_119239336154021_7323304262023249920_n.jpg?_nc_cat=100&_nc_eui2=AeHM5tOd8EdGVyuFbbG54sJAZAhjLSOLuOOGpVYJSD1XnyPDoOVlsdZSf5R0gtakF4G5Z2xJTywM0f0juJEp1skMOoRgC8pVKssXr902c1qKHQ&_nc_oc=AQl13lnuLgnfUW1rPovyBq_wP3YtwRywASGrdJ_jWN9sGc8mhxzMJzEqyntf8TbsbRo&_nc_ht=scontent-sin6-1.xx&oh=32679df2adfa3522bb48ce58f745f885&oe=5E1BA021',
        product_name: 'Le Mineral Botol 1500ml',
        product_description: 'Le Mineral Botol 1500ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0454',
        price: 5000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73063390_119241326153822_3412271441301733376_n.jpg?_nc_cat=104&_nc_eui2=AeG6B7n7LrfqPbs94FrdEIOqlIDUsCr67V3M-yCCiaCHevKnPjfqg6t6B8g127Iaw0YJEdJUnI_QK32iMajosqrCw1Q7bl5Wz52syI2n2wo5Ww&_nc_oc=AQnSg1dmBGhK8WIn8IwfnqSI-OeMADOqcW3ClN5YAsN_nzKJFQFNrvU4rzV596iRx3E&_nc_ht=scontent-sin6-1.xx&oh=4647f767307709a5e5c310561278f32f&oe=5E28084E',
        product_name: 'Le Mineral Botol 600ml',
        product_description: 'Le Mineral Botol 600ml/dus 24 botol', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0126',
        price: 42000
        }),  
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73063390_119241326153822_3412271441301733376_n.jpg?_nc_cat=104&_nc_eui2=AeG6B7n7LrfqPbs94FrdEIOqlIDUsCr67V3M-yCCiaCHevKnPjfqg6t6B8g127Iaw0YJEdJUnI_QK32iMajosqrCw1Q7bl5Wz52syI2n2wo5Ww&_nc_oc=AQnSg1dmBGhK8WIn8IwfnqSI-OeMADOqcW3ClN5YAsN_nzKJFQFNrvU4rzV596iRx3E&_nc_ht=scontent-sin6-1.xx&oh=4647f767307709a5e5c310561278f32f&oe=5E28084E',
        product_name: 'Le Mineral Botol 600ml',
        product_description: 'Le Mineral Botol 600ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0548',
        price: 2000
        }),          
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/74343856_119243082820313_3901055521498595328_n.jpg?_nc_cat=105&_nc_eui2=AeHO5ZmcGlnPFoNu_zkWSFQQX5f09fcVVZ_mlSC7xZ13GGP9n6qOCQIsaZoPJKpP6EnHhB1pHwHjJ727y4iHTIyzDRTuVzM2nUcKYy072s9H4Q&_nc_oc=AQnySd3SkQ8E5RbBcspSfYPKLAV9BitR-QyJHNVHzyTF_Amw1HtYevGe1BctZ3jacYU&_nc_ht=scontent-sin6-1.xx&oh=33a7995d8c1235f354df7db79878c006&oe=5E63318E',
        product_name: 'Le Mineral 330ml',
        product_description: 'Le Mineral 3330ml/dus 24pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0125',
        price: 34000
        }),    
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73078931_119257142818907_2297424405162098688_n.jpg?_nc_cat=101&_nc_eui2=AeHhZ-DoWkscCSHf0b2f2eGLDh-OpxLcgrmCmQ7K-krOBmo4UxJ2QkrWEVQjJCe2ghr_K7MDCddJt_bH1UvCWRSP7DpRl9kAkVE7wvGKIbJdLA&_nc_oc=AQm4Q4E30KvX5XO2FiIfVRQu9_yGv6qI8P1UqQ2rokVmcTmp15Y03GT5VXicfUv5AEU&_nc_ht=scontent-sin6-1.xx&oh=39e58f36f1273d8441b240578886edaf&oe=5E1E7A5F',
        product_name: 'Cleo Galon 19lt',
        product_description: 'Cleo Galon 19lt', 
        product_category: 'Galon',
        product_sub_category: 'Mineral',
        product_code: 'A0254',
        price: 18000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72366616_119261409485147_967511550304714752_n.jpg?_nc_cat=104&_nc_eui2=AeE5mBKG6RdfRgoFsDaOROtOLuPKqcIxMobum2rF8j-tFW1JxNiqZCAoba3_uteGA3z9EdpDkzurSX4rbYBGOIC-l0-X9HXjmE9wAZEcS_NOrA&_nc_oc=AQmLlueRlHtHXQzOO_Qr_MQk5F0gsCz3Uso_9i4GxpAUHZ-Zhl6CIYSMbdVuQXn_Co4&_nc_ht=scontent-sin6-1.xx&oh=c96ff10d72dfcdfa5dbfed450b156f00&oe=5E2D8503',
        product_name: 'Cleo Botol 550ml',
        product_description: 'Cleo Botol 550ml/Dus 24pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0166',
        price: 34000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73320890_119260449485243_3489294193627496448_n.jpg?_nc_cat=103&_nc_eui2=AeEvG_E88NeeRMJ_EVfG4fF-q-AVdUc5XoolxSXo-gvDwaBayryDVeQN9bo4awYreHktd1KArWEf0_yRCJ0I5MBObbSZq1BOK_5YlmeIC0M9xw&_nc_oc=AQk4S_qKlVL-zT6HFpCS38oNmeo6jH_CZD9fcy5YjBaiejeQKCrwI1_j09tVmc_yUos&_nc_ht=scontent-sin6-1.xx&oh=da4ff359830fffd24c5f89683072bcef&oe=5E181F90',
        product_name: 'Cleo Smart Botol 220ml',
        product_description: 'Cleo Botol 220ml/Dus 24pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0466',
        price: 20000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72335999_119263856151569_7679701305375326208_n.jpg?_nc_cat=101&_nc_eui2=AeHBJSM0EFgaUXE9Y7GHnG1XZEwQt6ZV-wg2zVM_Lv6UCy1EaTMHcoFcLtlUPIhzrc9IB6ZkCAcCpbEF3dMXH2fbPWc85IPbEvPe0kvl6BsF-w&_nc_oc=AQkL8-CYZhNj0_kFCoNnkXBowt9wb5qyEvFMsJH-xAF6e-2VwpZAYHfRxVBcEzj26iM&_nc_ht=scontent-sin6-1.xx&oh=7dd9b88892c0d204e2a5be6ec401e6c5&oe=5E5E0F32',
        product_name: 'Cleo Botol 330ml',
        product_description: 'Cleo Botol 330ml/Dus 24pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0258',
        price: 30000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73341405_119265662818055_6616625328280305664_n.jpg?_nc_cat=101&_nc_eui2=AeHDuE-_vD2BJTAnfKKG_QFFCzb0MhQd_Pi_ncq8UdKm7pkBli_iYU-tGfd8RaFq_vLKm6yVfGEnoGKFBSCexbRU_0dQusnaJQZnA6TWCkrd4w&_nc_oc=AQnaZQWQ-54TqfQpiUtdcNGpGOYYbVYy-vagQ-0qnLSV-nGSNKfKv8jyviSVGqi32-A&_nc_ht=scontent-sin6-1.xx&oh=2da6511f720a83e2fda406d5adb65da1&oe=5E310913',
        product_name: 'Cleo Gelas 250ml',
        product_description: 'Cleo Gelas 250ml/Dus 48pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0165',
        price: 22000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72419930_119269362817685_857228953490817024_n.jpg?_nc_cat=109&_nc_eui2=AeHvt5Hl_KXrV_5rBbKgLlgUotQGZjwA_7kR2uKRonhG5NH8frt7V6m9_-FW8vTNaxEc8UF3WLVwU4R6Mf7YXky2rr15LrhEBJfL0gbIOq2WUA&_nc_oc=AQnFd1Fxa-cZj-X6RqAnGsaCElq6exZHtA4i1iIyeCQX1L6zIRqL5JzU8_90v0bgOuU&_nc_ht=scontent-sin6-1.xx&oh=e3916354fcbd08c098a0f7e760f63c81&oe=5E1EE0AE',
        product_name: 'Nestle Botol 1500ml',
        product_description: 'Nestle Botol 1500ml/dus', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0256',
        price: 49000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72419930_119269362817685_857228953490817024_n.jpg?_nc_cat=109&_nc_eui2=AeHvt5Hl_KXrV_5rBbKgLlgUotQGZjwA_7kR2uKRonhG5NH8frt7V6m9_-FW8vTNaxEc8UF3WLVwU4R6Mf7YXky2rr15LrhEBJfL0gbIOq2WUA&_nc_oc=AQnFd1Fxa-cZj-X6RqAnGsaCElq6exZHtA4i1iIyeCQX1L6zIRqL5JzU8_90v0bgOuU&_nc_ht=scontent-sin6-1.xx&oh=e3916354fcbd08c098a0f7e760f63c81&oe=5E1EE0AE',
        product_name: 'Nestle Botol 1500ml',
        product_description: 'Nestle Botol 1500ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0597',
        price: 5000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72961244_119270942817527_3782717017736347648_n.jpg?_nc_cat=110&_nc_eui2=AeEOasNcaaqwKYOb4NAtDICuvSocM_HizXQV2_WHl8TVjJraJ4vnl_kkVGiFpWWTLgP5cL6mHioH-uDht_vOAhhqNsSYT00thMPLDspwb09JzA&_nc_oc=AQko-W759ZS9H1di4AHJS9JrDFq2EL7nm1YNQe23owKSZmOnv4CBC1PrIkOWm4owOCY&_nc_ht=scontent-sin6-1.xx&oh=6c4d032a5ad7f2ffa486ba3def0d65c1&oe=5E261A0C',
        product_name: 'Nestle Botol 600ml',
        product_description: 'Nestle Botol 600ml/dus', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0173',
        price: 47000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72961244_119270942817527_3782717017736347648_n.jpg?_nc_cat=110&_nc_eui2=AeEOasNcaaqwKYOb4NAtDICuvSocM_HizXQV2_WHl8TVjJraJ4vnl_kkVGiFpWWTLgP5cL6mHioH-uDht_vOAhhqNsSYT00thMPLDspwb09JzA&_nc_oc=AQko-W759ZS9H1di4AHJS9JrDFq2EL7nm1YNQe23owKSZmOnv4CBC1PrIkOWm4owOCY&_nc_ht=scontent-sin6-1.xx&oh=6c4d032a5ad7f2ffa486ba3def0d65c1&oe=5E261A0C',
        product_name: 'Nestle Botol 600ml',
        product_description: 'Nestle Botol 600ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0495',
        price: 3000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73067825_119272356150719_8384530504078065664_n.jpg?_nc_cat=110&_nc_eui2=AeHDTRtko9loQ2A-bjrU4v7CFhflm7R6VfHavK3-W2WR5yugMeO2wVSUAwh5ixAEAkEAGF2JjT6V64SS_RaBo_U9B5wHKlx8hRjRp-5VnJQO9w&_nc_oc=AQnh9wlDfYwtvMycRCuqAM8kkzchj2pjWZMeF0fwAe_NlLiK4q-2g8ZRsMahxHmR_gQ&_nc_ht=scontent-sin6-1.xx&oh=77ba34e6e31a8d1aabdd620cda3f7386&oe=5E61E306',
        product_name: 'Nestle Botol 330ml',
        product_description: 'Nestle Botol 330ml/dus', 
        product_category: 'Kemasan',
        product_sub_category: 'Mineral',
        product_code: 'A0167',
        price: 38000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72681618_119274322817189_5171517451929649152_n.jpg?_nc_cat=103&_nc_eui2=AeHGjWNKSepzcaWx1Mp4zxv2JkxD2V5JGR1Zs53k5-8qR8O1feJWHCeOZf7Sqz_gsbw0oU7yU13zvQM_L19yIK1sGDXSaz16VDuHsl5vzwNi5A&_nc_oc=AQk1EqYzK2gqsFlz8hlPMfNRXl46cfq5IJApCiF2loAuTeYQ8dKZCVMAvVPILa1hb7U&_nc_ht=scontent-sin6-1.xx&oh=b423f5532b8d126b8ff69d48979ece67&oe=5E33B6F8',
        product_name: 'Teh Pucuk 350ml',
        product_description: 'Teh Pucuk 350ml/pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Teh',
        product_code: 'A0128',
        price: 4000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72774820_119275772817044_3108563523433660416_o.jpg?_nc_cat=105&_nc_eui2=AeE3TKf9aGGAxmh0J1WQVY3tSDxddo1Cip0LX3udVWOgrnhk52V_wIgBDir3zxwPhMG1DNey_lja0pOcb6KzFNsHBGrRbNG2FWRtwwPFE_A4Bg&_nc_oc=AQnXnwKFTFrcxiAdgUzVcSVFc71e07c0cLQmW_4hYXypBHhiXJGifh9mULBK4Vysr28&_nc_ht=scontent-sin6-1.xx&oh=3aa411399f2926352ee42e3b834c7fe5&oe=5E1E3384',
        product_name: 'Teh Pucuk 350ml',
        product_description: 'Teh Pucuk 350ml/dus 24pcs', 
        product_category: 'Kemasan',
        product_sub_category: 'Teh',
        product_code: 'A0092',
        price: 57000
        }),           
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72731475_119280576149897_1770045963591745536_n.jpg?_nc_cat=110&_nc_eui2=AeFGYdC7fM2HM7BFej9X5xfIeyj8ghbaz6NoumtIkSnmLeKE-YO0ed-dkwh4m4aEQPcNQ3mRbAAaJqQBjy0jmDywcAeSeFicEwqGFA0-uHGdjQ&_nc_oc=AQmdXHZ32OwCYM7ryQXMXf2-G1-LiwmYwz2v3z-XJjgBZyPK857niNdO9kf3KGNabek&_nc_ht=scontent-sin6-1.xx&oh=9447d8a64addcb3ac8a2415adf059fc0&oe=5E2D93A3',
        product_name: 'Teh Gelas',
        product_description: 'Teh Gelas/Dus', 
        product_category: 'Kemasan',
        product_sub_category: 'Teh',
        product_code: 'A0417',
        price: 22000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72610291_119285336149421_5710184875735121920_n.jpg?_nc_cat=106&_nc_eui2=AeHS8elUUcv8S9jvSNvbRf26dgOyBsBWmIUPv6bPtCtsp0Kb9ZDoFypyKDI8LMM03rmqUGCmIBDksLeX6tTzxHip0_cLIL17Vtmp7hAD31owjQ&_nc_oc=AQnOgarJl9R7JQDj1Ae2mkw5jrfzmS8FjaB_8Ud8Q7DrE2_1ZVK06_ck5hW991_igeg&_nc_ht=scontent-sin6-1.xx&oh=f72e34c013855b66da27689c505a39f9&oe=5E1EC271',
        product_name: 'Gas Elpiji 12kg',
        product_description: 'Gas Elpiji 12kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0002',
        price: 155000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73325567_119286279482660_2480088389303402496_n.jpg?_nc_cat=106&_nc_eui2=AeGrm2RjQVT9Lwdeid9nmiJfAFa1q7mkp8JS2CualZHjkNLpwULU_90OOuajyENsC-jHZs1sGwIE6VH4uQkclhPoJoCBYb3GItGzrCqHimkgbg&_nc_oc=AQlPgXz7mbD2GhhLxNEnG1BeyQC9SiLvsaNIHJD0OFtRhbccYrVFbwgNAFv5PSks06M&_nc_ht=scontent-sin6-1.xx&oh=f3603acf448db8c7f928c539cc04a154&oe=5E1CC30F',
        product_name: 'Gas Elpiji 5,5kg',
        product_description: 'Gas Elpiji 5,5kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0003',
        price: 75000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72332546_119287199482568_7073379810126331904_n.jpg?_nc_cat=108&_nc_eui2=AeHh0zHG7FQ6QJlfW-A9Vq5RCv4tTxS2-kjStr4leOezfxxjO_VKvdHF500h_3FVjx_WiU95qn2vdwEbJjUJ8potIFB0ivgGFGltOIj4_PzIiQ&_nc_oc=AQkBtEAirBJ2VPqYB02BXvD1RYoZxFnZ4vjtXrFU7ZiQT-PhJ6x-3qzJbP1E_3nnLP8&_nc_ht=scontent-sin6-1.xx&oh=4f71da70c87e87b8a91bfa2a0833b4e3&oe=5E22CFB3',
        product_name: 'Gas Elpiji 3kg',
        product_description: 'Gas Elpiji 3kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0004',
        price: 21000
        }), 
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72610291_119285336149421_5710184875735121920_n.jpg?_nc_cat=106&_nc_eui2=AeHS8elUUcv8S9jvSNvbRf26dgOyBsBWmIUPv6bPtCtsp0Kb9ZDoFypyKDI8LMM03rmqUGCmIBDksLeX6tTzxHip0_cLIL17Vtmp7hAD31owjQ&_nc_oc=AQnOgarJl9R7JQDj1Ae2mkw5jrfzmS8FjaB_8Ud8Q7DrE2_1ZVK06_ck5hW991_igeg&_nc_ht=scontent-sin6-1.xx&oh=f72e34c013855b66da27689c505a39f9&oe=5E1EC271',
        product_name: 'Tabung Gas Kosong Elpiji 12kg',
        product_description: 'Tabung kosong Gas Elpiji 12kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0005',
        price: 300000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/73325567_119286279482660_2480088389303402496_n.jpg?_nc_cat=106&_nc_eui2=AeGrm2RjQVT9Lwdeid9nmiJfAFa1q7mkp8JS2CualZHjkNLpwULU_90OOuajyENsC-jHZs1sGwIE6VH4uQkclhPoJoCBYb3GItGzrCqHimkgbg&_nc_oc=AQlPgXz7mbD2GhhLxNEnG1BeyQC9SiLvsaNIHJD0OFtRhbccYrVFbwgNAFv5PSks06M&_nc_ht=scontent-sin6-1.xx&oh=f3603acf448db8c7f928c539cc04a154&oe=5E1CC30F',
        product_name: 'Tabung Gas Kosong Elpiji 5,5kg',
        product_description: 'Tabung Gas kosong Elpiji 5,5kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0006',
        price: 75000
        }),
    new Product({
        imagePath: 'https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/72332546_119287199482568_7073379810126331904_n.jpg?_nc_cat=108&_nc_eui2=AeHh0zHG7FQ6QJlfW-A9Vq5RCv4tTxS2-kjStr4leOezfxxjO_VKvdHF500h_3FVjx_WiU95qn2vdwEbJjUJ8potIFB0ivgGFGltOIj4_PzIiQ&_nc_oc=AQkBtEAirBJ2VPqYB02BXvD1RYoZxFnZ4vjtXrFU7ZiQT-PhJ6x-3qzJbP1E_3nnLP8&_nc_ht=scontent-sin6-1.xx&oh=4f71da70c87e87b8a91bfa2a0833b4e3&oe=5E22CFB3',
        product_name: 'Tabung Gas Kosong Elpiji 3kg',
        product_description: 'Tabung Gas Kosong Elpiji 3kg', 
        product_category: 'Tabung',
        product_sub_category: 'Gas',
        product_code: 'A0007',
        price: 125000
        }),                    
   ];


var done = 0; 
for (var i = 0; i < products.length; i++) {
     products[i].save(function(err, result) {
        done++;
        if (done === products.length){
            exit();            
        }
    });
}

function exit() {
    mongoose.disconnect();
}
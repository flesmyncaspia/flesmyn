var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var schema = new Schema({
    imagePath: {type: String, required:true},
    product_name: {type: String, required:true},
    product_description: {type: String, required:true},
    product_category: {type: String, required:true},
    product_sub_category: {type: String, required:true},
    product_code: {type: String, required:true},
    price: {type: Number, required:true}
});

module.exports = mongoose.model('Product', schema);
